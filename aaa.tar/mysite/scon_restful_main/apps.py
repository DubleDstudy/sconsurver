from django.apps import AppConfig


class SconRestfulMainConfig(AppConfig):
    name = 'scon_restful_main'
