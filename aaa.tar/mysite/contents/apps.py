from django.apps import AppConfig


class ContentsConfig(AppConfig):
    name = 'contents'
