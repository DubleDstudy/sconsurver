from django.apps import AppConfig


class Comment1Config(AppConfig):
    name = 'comment1'
